@extends('layouts.admin')
@section('content')
 Market Details

@endsection