@extends('layouts.admin2')
@section('content')

register crop
@endsection