@extends('layouts.admin2')
@section('content')

register farmer
@endsection