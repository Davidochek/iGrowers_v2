<?php return array (
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
);