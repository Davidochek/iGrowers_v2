
<?php $__env->startSection('content'); ?>

         <section class="tp-banner-container">
            <div class="tp-banner">
                <ul>
                    <li data-transition="slidevertical" data-slotamount="1" data-masterspeed="1000"
                        data-saveperformance="off" data-title="Slide">
                        <img src="<?php echo e(asset('assets/img/slide/1.jpg')); ?>" alt="fullslide1" data-bgposition="center center"
                            data-kenburns="on" data-duration="6000" data-ease="Linear.easeNone" data-bgfit="130"
                            data-bgfitend="100" data-bgpositionend="right center">
                    </li>
                </ul>
                <div class="tp-bannertimer"></div>
            </div>
            <div class="filter-title">
                <div class="title-header">
                    <h2 style="color:#fff;"><?php echo e($pests->name); ?> Pests</h2>
                    <p class="lead">For what <?php echo e($pests->name); ?> pests do you seek the services </p>
                </div>
                <div class="filter-header">
                    <form id="sform" action="pests" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" id="q" name="q" required="required" placeholder="Start typing name to find pest"
                            class="input-large typeahead" autocomplete="off">
                        <input type="submit" name="submit" value="Search">
                    </form>
                </div>
            </div>
        </section>
        <section class="content-central">
            <div class="content_info" style="margin-top: -70px;">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="services-lines full-services">
                        	<?php $__currentLoopData = $pests->pests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="item-service-line">
                                    <i class="fa"><a href="<?php echo e(url('/showPestDetails/' .$pest->id)); ?>"><img class="icon-img img-responsive" style="height: 100px;" 
                                                src="<?php echo e(asset ($pest->image1)); ?>" alt="AC"></a></i>
                                    <h5><?php echo e($pest->name); ?></h5>
                                </div>
                            </li>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="content_info content_resalt">
                <div class="container">
                    <div class="row">
                        <div class="titles">
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sw\igrowers\igrowers-v2\resources\views/crops/showpests.blade.php ENDPATH**/ ?>