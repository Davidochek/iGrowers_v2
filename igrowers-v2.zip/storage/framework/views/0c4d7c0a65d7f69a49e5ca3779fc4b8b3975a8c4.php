
<?php $__env->startSection('content'); ?>

register crop
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sw\igrowers\igrowers-v2\resources\views/admins/register-crop.blade.php ENDPATH**/ ?>